"use strict"
const {Chat} = require('../models');

async function saveChatMessage(user, message) {
}

module.exports = {
  saveChatMessage,
};