"use strict";

module.exports = {
  ...require("./chats"),
};
