"use strict";

const ENV = {
  DEVELOPMENT: "development",
  PRODUCTION: "production",
  TEST: "test",
};

const RELEASE = {
  PRODUCTION: "production",
  STAGING: "staging",
};
module.exports = {
  ENV,
  RELEASE,
};
