"use strict";

const DELETION_TYPE = {
  FOR_ME: "for_me",
  FOR_EVERYONE:"for_everyone"
};

module.exports = {
  DELETION_TYPE
};
